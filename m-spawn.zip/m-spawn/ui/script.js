document.addEventListener('DOMContentLoaded', function() {
    const locations = document.querySelectorAll('.location');

    locations.forEach(location => {
        location.addEventListener('click', function() {
            const selectedLocation = this.getAttribute('data-location');
            fetch(`https://m-spawn/spawnPlayer`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json; charset=UTF-8',
                },
                body: JSON.stringify({
                    location: selectedLocation
                })
            }).then(resp => resp.json()).then(resp => console.log(resp));
        });
    });
});

window.addEventListener('message', function(event) {
    if (event.data.type === "open") {
        document.querySelector('.container').style.display = 'block';
    }
});

function closeSpawnSelector() {
    fetch(`https://m-spawn/close`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({})
    }).then(resp => resp.json()).then(resp => console.log(resp));
}