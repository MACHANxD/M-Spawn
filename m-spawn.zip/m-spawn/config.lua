Config = {}

Config.SpawnLocations = {
    {name = "Spawn 1", coords = vector4(-1045.67, -2751.31, 21.36, 327.81)},
    {name = "Spawn 2", coords = vector4(-1038.45, -2737.85, 20.17, 327.81)},
    {name = "Spawn 3", coords = vector4(-1025.47, -2722.10, 20.17, 327.81)},
    {name = "Spawn 4", coords = vector4(-1012.49, -2706.35, 20.17, 327.81)},
    {name = "Spawn 5", coords = vector4(-999.51, -2690.60, 20.17, 327.81)},
}

Config.LastLocation = true -- Enable or disable the last location option