local QBCore = exports['qb-core']:GetCoreObject()

local isSpawnSelectorOpen = false

-- Listen for the event when a player selects a character
RegisterNetEvent('qb-multicharacter:client:chooseChar')
AddEventHandler('qb-multicharacter:client:chooseChar', function()
    -- Open the spawn selector after character selection
    TriggerEvent('m-spawn:client:openSpawnSelector')
end)

RegisterNetEvent('m-spawn:client:openSpawnSelector')
AddEventHandler('m-spawn:client:openSpawnSelector', function()
    if not isSpawnSelectorOpen then
        isSpawnSelectorOpen = true
        SetNuiFocus(true, true)
        SendNUIMessage({
            type = "open",
            locations = Config.SpawnLocations,
            lastLocation = Config.LastLocation
        })
    end
end)

RegisterNUICallback('close', function(data, cb)
    isSpawnSelectorOpen = false
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('spawnPlayer', function(data, cb)
    local location = data.location
    if location == "last" then
        -- Fetch the last location from the server
        QBCore.Functions.TriggerCallback('m-spawn:server:getLastLocation', function(coords)
            if coords then
                TriggerServerEvent('m-spawn:server:spawnPlayer', coords)
            else
                -- If no last location, spawn at default location
                local defaultCoords = Config.SpawnLocations[1].coords
                TriggerServerEvent('m-spawn:server:spawnPlayer', defaultCoords)
            end
        end)
    else
        local coords = Config.SpawnLocations[location].coords
        TriggerServerEvent('m-spawn:server:spawnPlayer', coords)
    end
    cb('ok')
end)