RegisterNetEvent('m-spawn:client:spawnPlayer')
AddEventHandler('m-spawn:client:spawnPlayer', function(coords)
    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do
        Wait(0)
    end
    SetEntityCoords(PlayerPedId(), coords.x, coords.y, coords.z, false, false, false, true)
    SetEntityHeading(PlayerPedId(), coords.w)
    DoScreenFadeIn(500)
end)