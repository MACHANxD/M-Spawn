local QBCore = exports['qb-core']:GetCoreObject()

-- Save the player's last location
RegisterNetEvent('m-spawn:server:saveLastLocation')
AddEventHandler('m-spawn:server:saveLastLocation', function(coords)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local citizenid = Player.PlayerData.citizenid
        MySQL.Async.execute('UPDATE players SET last_location = ? WHERE citizenid = ?', {
            json.encode(coords),
            citizenid
        })
    end
end)

-- Get the player's last location
QBCore.Functions.CreateCallback('m-spawn:server:getLastLocation', function(source, cb)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local citizenid = Player.PlayerData.citizenid
        MySQL.Async.fetchScalar('SELECT last_location FROM players WHERE citizenid = ?', { citizenid }, function(result)
            if result then
                cb(json.decode(result))
            else
                cb(nil)
            end
        end)
    else
        cb(nil)
    end
end)

-- Spawn the player at the selected location
RegisterNetEvent('m-spawn:server:spawnPlayer')
AddEventHandler('m-spawn:server:spawnPlayer', function(coords)
    local src = source
    TriggerClientEvent('m-spawn:client:spawnPlayer', src, coords)
    -- Save the spawn location as the last location
    TriggerEvent('m-spawn:server:saveLastLocation', coords)
end)