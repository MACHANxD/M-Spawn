fx_version 'cerulean'
game 'gta5'

author 'Your Name'
description 'm-spawn: A modern and sleek spawn selector for QBCore'
version '1.0.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js',
}

client_scripts {
    'config.lua',
    'client/cl_main.lua',
    'client/cl_spawnselector.lua',
}

server_scripts {
    'config.lua',
    'server/sv_main.lua',
}