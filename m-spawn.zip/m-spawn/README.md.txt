# m-spawn

A modern and sleek spawn selector for QBCore.

## Features
- 5 customizable spawn locations
- Option to spawn at last location
- Modern and premium UI design

## Installation
1. Download the script and place it in your `resources` folder.
2. Add `ensure m-spawn` to your `server.cfg`.
3. Configure the spawn locations in `config.lua`.
4. Restart your server.
For last location .run this query in your database
ALTER TABLE players ADD COLUMN last_location LONGTEXT;
## Usage
- Use the `/spawn` command to open the spawn selector.